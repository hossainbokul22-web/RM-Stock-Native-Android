package com.rmstock.nativeapp;
import android.database.sqlite.SQLiteDatabase;
import com.googlecode.tesseract.android.TessBaseAPI;

import android.Manifest;import android.app.*;import android.content.*;import android.content.pm.PackageManager;import android.graphics.*;import android.graphics.pdf.PdfDocument;import android.net.Uri;import android.os.*;import android.print.*;import android.provider.MediaStore;import android.view.*;import android.widget.*;import androidx.annotation.Nullable;import android.app.Activity;import androidx.core.app.ActivityCompat;import androidx.core.content.ContextCompat;import androidx.core.content.FileProvider;import com.googlecode.tesseract.android.TessBaseAPI;import org.json.*;import java.io.*;import java.text.*;import java.util.*;import java.util.concurrent.*;

public class MainActivity extends Activity {
 private StockDb db; private LinearLayout root,content; private Uri photoUri; private static final int CAM=77,PHOTO=78; private final Handler main=new Handler(Looper.getMainLooper()); private final String role="Owner/Admin";
 private File pendingPdf; private final List<Runnable> dashboardRunnables=new ArrayList<>(); private int dp(float n){return (int)(n*getResources().getDisplayMetrics().density+.5f);} private TextView title(String s){TextView t=new TextView(this);t.setText(s);t.setTextSize(22);t.setTypeface(null,1);t.setPadding(dp(4),dp(12),dp(4),dp(10));return t;} private Button btn(String s){Button b=new Button(this);b.setText(s);b.setAllCaps(false);return b;} private EditText edit(String hint){EditText e=new EditText(this);e.setHint(hint);e.setSingleLine(true);e.setPadding(dp(10),dp(4),dp(10),dp(4));return e;} private LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.HORIZONTAL);l.setGravity(Gravity.CENTER_VERTICAL);l.setPadding(0,dp(3),0,dp(3));return l;} private void add(View v){content.addView(v,new LinearLayout.LayoutParams(-1,-2));}
 @Override public void onCreate(Bundle b){super.onCreate(b);db=new StockDb(this);db.setSetting("role","Owner/Admin");build();showDashboard();}

 @Override public void onBackPressed(){ showDashboard(); }

 private void build(){
        root=new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(android.graphics.Color.rgb(245,247,250));

        LinearLayout header=new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(dp(10),dp(5),dp(12),dp(5));
        header.setBackgroundColor(android.graphics.Color.rgb(20,55,95));

        Button back=btn("‹  Back");
        back.setTextColor(Color.WHITE);
        back.setTextSize(13);
        back.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(35,75,118)));
        back.setMinWidth(dp(64));
        back.setPadding(dp(4),0,dp(4),0);
        back.setOnClickListener(v->showDashboard());
        header.addView(back,new LinearLayout.LayoutParams(dp(72),dp(44)));

        LinearLayout brandBox=new LinearLayout(this);
        brandBox.setOrientation(LinearLayout.VERTICAL);
        brandBox.setGravity(Gravity.CENTER_VERTICAL);
        brandBox.setPadding(dp(10),0,0,0);
        TextView brand=new TextView(this);
        brand.setText("RM STOCK");
        brand.setTextColor(android.graphics.Color.WHITE);
        brand.setTextSize(19);
        brand.setTypeface(null,android.graphics.Typeface.BOLD);
        brandBox.addView(brand);

        TextView sub=new TextView(this);
        sub.setText("Inventory Management • Offline");
        sub.setTextColor(android.graphics.Color.WHITE);
        sub.setTextSize(12);
        brandBox.addView(sub);
        header.addView(brandBox,new LinearLayout.LayoutParams(0,-2,1));

        root.addView(header,new LinearLayout.LayoutParams(-1,dp(64)));

        ScrollView sv=new ScrollView(this);
        content=new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(14),dp(14),dp(14),dp(14));
        sv.addView(content);
        root.addView(sv,new LinearLayout.LayoutParams(-1,0,1));

        HorizontalScrollView navScroll=new HorizontalScrollView(this);
        navScroll.setHorizontalScrollBarEnabled(false);
        navScroll.setFillViewport(false);
        LinearLayout nav=new LinearLayout(this);
        nav.setOrientation(LinearLayout.HORIZONTAL);
        nav.setPadding(dp(4),dp(4),dp(4),dp(4));
        nav.setBackgroundColor(android.graphics.Color.WHITE);

        String[] ns={"⌂\nDashboard","＋\nDaily Entry","▣\nBatch","▤\nReports","◆\nMaster","◇\nRecipe","⚙\nCustom","✦\nAI"};
        for(String navLabel:ns){
            final String n=navLabel.substring(navLabel.indexOf('\n')+1);
            Button b=btn(navLabel);
            b.setTextSize(10);
            b.setAllCaps(false);
            b.setMinWidth(dp(76));
            b.setPadding(dp(5),0,dp(5),0);
            b.setOnClickListener(v->{
                if(n.equals("Dashboard"))showDashboard();
                else if(n.equals("Daily Entry"))showDaily();
                else if(n.equals("Batch"))showBatch();
                else if(n.equals("Reports"))showReports();
                else if(n.equals("Master"))showMaster();
                else if(n.equals("Recipe"))showRecipe();
                else if(n.equals("Custom"))showCustom();
                else showAI();
            });
            nav.addView(b,new LinearLayout.LayoutParams(dp(78),dp(54)));
        }
        navScroll.addView(nav);
        root.addView(navScroll,new LinearLayout.LayoutParams(-1,dp(62)));
        setContentView(root);
    }

    private void clear(String head){for(Runnable task:dashboardRunnables)main.removeCallbacks(task);dashboardRunnables.clear();content.removeAllViews();add(title(head));TextView r=new TextView(this);r.setText("Role: "+role+"   •   Offline Native Android");r.setPadding(0,0,0,dp(8));content.addView(r);}
 private boolean admin(){return true;}
 private void showDashboard(){
    clear("Dashboard");
    try{
        TextView live=new TextView(this); live.setText("LIVE DATA  •  Today’s RM Receive, Mixing-2 Use, Batch and Closing Stock");
        live.setTextSize(12); live.setTextColor(Color.rgb(77,101,124)); live.setPadding(dp(2),0,dp(2),dp(10)); add(live);

        LinearLayout grid=new LinearLayout(this); grid.setOrientation(LinearLayout.VERTICAL);
        LinearLayout r1=row(),r2=row();
        TextView receiveValue=new TextView(this),useValue=new TextView(this),batchValue=new TextView(this),closingValue=new TextView(this);
        addLiveCard(r1,"Today RM Receive",receiveValue,"#EAF7EF");
        addLiveCard(r1,"Today Mixing-2 Use",useValue,"#EEF4FC");
        addLiveCard(r2,"Today Batch",batchValue,"#FFF5E8");
        addLiveCard(r2,"Today Closing Stock",closingValue,"#F3EEFC");
        grid.addView(r1); grid.addView(r2); add(grid);

        String d=today();
        List<String> receives=new ArrayList<>(), uses=new ArrayList<>(), batches=new ArrayList<>(), closings=new ArrayList<>();
        for(JSONObject x:db.rows("SELECT r.rm_code, m.name, m.uom, SUM(r.qty) qty FROM receives r LEFT JOIN rms m ON m.code=r.rm_code WHERE r.date=? GROUP BY r.rm_code,m.name,m.uom HAVING ABS(SUM(r.qty))>0.0000001 ORDER BY CAST(r.rm_code AS INTEGER)",new String[]{d}))
            receives.add(x.optString("rm_code")+" • "+x.optString("name","RM")+"  "+fmt(x.optDouble("qty"))+" "+x.optString("uom","kg"));
        for(JSONObject x:db.rows("SELECT l.rm_code,m.name,m.uom,SUM(l.consumption) qty FROM mixing2_batch_log l LEFT JOIN rms m ON m.code=l.rm_code WHERE l.date=? GROUP BY l.rm_code,m.name,m.uom HAVING ABS(SUM(l.consumption))>0.0000001 ORDER BY CAST(l.rm_code AS INTEGER)",new String[]{d}))
            uses.add(x.optString("rm_code")+" • "+x.optString("name","RM")+"  "+fmt(x.optDouble("qty"))+" "+x.optString("uom","kg"));
        for(JSONObject x:db.rows("SELECT b.product_code,p.name,b.shift,SUM(b.qty) qty FROM batches b LEFT JOIN products p ON p.code=b.product_code WHERE b.date=? GROUP BY b.product_code,p.name,b.shift ORDER BY b.product_code,b.shift",new String[]{d}))
            batches.add(x.optString("name", "Product "+x.optString("product_code"))+" • Shift "+x.optString("shift")+"  "+fmt(x.optDouble("qty"))+" batch");
        double totalReceive=0,totalUse=0;
        JSONObject tr=db.one("SELECT COALESCE(SUM(qty),0) qty FROM receives WHERE date=?",new String[]{d}); if(tr!=null)totalReceive=tr.optDouble("qty");
        JSONObject tu=db.one("SELECT COALESCE(SUM(consumption),0) qty FROM mixing2_batch_log WHERE date=?",new String[]{d}); if(tu!=null)totalUse=tu.optDouble("qty");
        int batchCount=0; JSONObject bc=db.one("SELECT COUNT(*) n FROM batches WHERE date=?",new String[]{d}); if(bc!=null)batchCount=bc.optInt("n");
        for(JSONObject rm:db.rows("SELECT code,name,uom FROM rms ORDER BY CAST(code AS INTEGER)",null)){
            String code=rm.getString("code"); double open=rm.optDouble("opening");
            JSONObject rec=db.one("SELECT COALESCE(SUM(qty),0) qty FROM receives WHERE rm_code=? AND date<=?",new String[]{code,d});
            JSONObject use=db.one("SELECT COALESCE(SUM(consumption),0) qty FROM mixing2_batch_log WHERE rm_code=? AND date<=?",new String[]{code,d});
            double closing=open+(rec==null?0:rec.optDouble("qty"))-(use==null?0:use.optDouble("qty"));
            closings.add(code+" • "+rm.getString("name")+"  "+fmt(closing)+" "+rm.getString("uom"));
        }
        startTicker(receiveValue,receives,"No RM receive today",totalReceive==0?"0.000 KG":fmt(totalReceive)+" KG");
        startTicker(useValue,uses,"No Mixing-2 use today",totalUse==0?"0.000 KG":fmt(totalUse)+" KG");
        startTicker(batchValue,batches,"No batch entered today",batchCount+" Batch");
        startTicker(closingValue,closings,"No raw materials",closings.isEmpty()?"0.000 KG":closings.get(0));

        addSectionTitle("Today Batch",Color.rgb(235,243,253));
        addSimpleTable(new String[]{"Product","Batch / Shift","Qty"},batches);
        addSectionTitle("Today Receive",Color.rgb(235,248,240));
        addSimpleTable(new String[]{"RM","Receive","UoM"},receives);
        addSectionTitle("Today Mixing-2 Use",Color.rgb(243,238,252));
        addSimpleTable(new String[]{"RM","Use","UoM"},uses);
        addSectionTitle("Stock Overview",Color.WHITE);
        if(closings.isEmpty()) addSimpleTable(new String[]{"Raw Material","Closing Stock"},closings);
        else {
            List<JSONObject> stock=db.rows("SELECT code,name,uom,opening FROM rms ORDER BY CAST(code AS INTEGER)",null);
            stock.sort((a,b)->{try{return Double.compare(closingFor(b.getString("code"),d),closingFor(a.getString("code"),d));}catch(Exception e){return 0;}});
            for(JSONObject rm:stock){double c=closingFor(rm.getString("code"),d); LinearLayout item=row(); item.setPadding(dp(10),dp(9),dp(10),dp(9)); item.setBackgroundColor(Color.WHITE); TextView nm=new TextView(this);nm.setText(rm.getString("name"));nm.setTextSize(14);nm.setTextColor(Color.rgb(55,70,84));nm.setLayoutParams(new LinearLayout.LayoutParams(0,-2,1));TextView q=new TextView(this);q.setText(fmt(c)+" "+rm.getString("uom"));q.setTextSize(14);q.setTypeface(null,Typeface.BOLD);q.setTextColor(c<0?Color.rgb(184,57,57):Color.rgb(35,75,110));item.addView(nm);item.addView(q);add(item);View line=new View(this);line.setBackgroundColor(Color.rgb(232,237,242));add(line);}
        }
        TextView owner=new TextView(this);owner.setText("Owner / Admin • Full offline access");owner.setTextSize(12);owner.setTextColor(Color.DKGRAY);owner.setPadding(0,dp(14),0,dp(10));add(owner);
    }catch(Exception e){error(e);}
 }
 private double closingFor(String code,String d)throws Exception{return opening(d,code)+receive(d,code)-use(d,code);}
 private void addLiveCard(LinearLayout parent,String label,TextView value,String color){LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.VERTICAL);card.setPadding(dp(12),dp(10),dp(10),dp(10));card.setBackgroundColor(Color.WHITE);TextView l=new TextView(this);l.setText(label);l.setTextSize(11);l.setTextColor(Color.rgb(100,113,126));value.setTextSize(17);value.setTypeface(null,Typeface.BOLD);value.setTextColor(Color.rgb(27,59,91));value.setSingleLine(true);value.setEllipsize(android.text.TextUtils.TruncateAt.END);card.addView(l);card.addView(value);LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(0,dp(78),1);cp.setMargins(dp(3),dp(3),dp(3),dp(3));parent.addView(card,cp);}
 private void startTicker(TextView view,List<String> items,String empty,String summary){if(items.isEmpty()){view.setText(empty);return;}view.setText(summary);final int[] idx={0};final Runnable[] task=new Runnable[1];task[0]=()->{if(!view.isAttachedToWindow())return;if(idx[0]>=items.size()){idx[0]=0;view.setText(summary);Runnable pause=()->{if(view.isAttachedToWindow())main.post(task[0]);};dashboardRunnables.add(pause);main.postDelayed(pause,2000);return;}view.animate().cancel();view.setAlpha(0.25f);view.setTranslationY(dp(5));view.setText(items.get(idx[0]++));view.animate().alpha(1f).translationY(0).setDuration(180).start();Runnable next=()->main.post(task[0]);dashboardRunnables.add(next);main.postDelayed(next,1000);};Runnable first=()->main.post(task[0]);dashboardRunnables.add(first);main.postDelayed(first,1000);}
 private void addSectionTitle(String text,int bg){TextView h=title(text);h.setTextSize(16);h.setPadding(dp(8),dp(10),dp(8),dp(10));h.setBackgroundColor(bg);add(h);}
 private void addSimpleTable(String[] headers,List<String> rows){LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.VERTICAL);card.setPadding(dp(8),dp(6),dp(8),dp(6));card.setBackgroundColor(Color.WHITE);if(rows.isEmpty()){TextView e=new TextView(this);e.setText("No entries today");e.setTextSize(13);e.setPadding(dp(6),dp(8),dp(6),dp(8));card.addView(e);}else{for(String value:rows){TextView t=new TextView(this);t.setText(value);t.setTextSize(13);t.setTextColor(Color.rgb(49,65,80));t.setPadding(dp(6),dp(7),dp(6),dp(7));card.addView(t);View divider=new View(this);divider.setBackgroundColor(Color.rgb(232,237,242));card.addView(divider,new LinearLayout.LayoutParams(-1,dp(1)));}}add(card);Space sp=new Space(this);add(sp);}

private void addDashCard(LinearLayout parent,String label,String value){
    LinearLayout card=new LinearLayout(this);
    card.setOrientation(LinearLayout.VERTICAL);
    card.setPadding(dp(16),dp(12),dp(16),dp(12));
    card.setBackgroundColor(Color.WHITE);

    TextView a=new TextView(this);
    a.setText(label);
    a.setTextSize(11);
    a.setTextColor(Color.DKGRAY);

    TextView b=new TextView(this);
    b.setText(value);
    b.setTextSize(24);
    b.setTypeface(null,Typeface.BOLD);
    b.setTextColor(Color.rgb(20,55,95));

    card.addView(a);
    card.addView(b);
    parent.addView(card,new LinearLayout.LayoutParams(-1,dp(76)));

    Space sp=new Space(this);
    parent.addView(sp,new LinearLayout.LayoutParams(1,dp(7)));
}

private void showMaster(){clear("Master Data — Dynamic Add / Edit");Button rm=btn("RM Master — Add / Edit");rm.setOnClickListener(v->showRmMaster());add(rm);Button p=btn("Product Master — Add / Edit");p.setOnClickListener(v->showProductMaster());add(p);TextView n=new TextView(this);n.setText("Product Code/Name changes are migrated through batch references; new Products automatically receive recipe quantity 0 for every RM.");n.setPadding(0,dp(12),0,0);add(n);}
 private void showRmMaster(){clear("RM Master");if(admin()){LinearLayout addrow=row();EditText c=edit("New RM Code"),n=edit("Name"),u=edit("UoM");addrow.addView(c,new LinearLayout.LayoutParams(0,dp(52),1));addrow.addView(n,new LinearLayout.LayoutParams(0,dp(52),2));addrow.addView(u,new LinearLayout.LayoutParams(0,dp(52),1));Button a=btn("Add");addrow.addView(a);a.setOnClickListener(v->{try{String code=c.getText().toString().trim(),name=n.getText().toString().trim(),uom=u.getText().toString().trim();if(code.isEmpty()||name.isEmpty())throw new Exception("Code and name required");if(db.one("SELECT code FROM rms WHERE code=?",new String[]{code})!=null)throw new Exception("Duplicate RM Code");ContentValues z=new ContentValues();z.put("code",code);z.put("name",name);z.put("uom",uom.isEmpty()?"kg":uom);z.put("opening",0);db.insert("rms",z);for(JSONObject p:db.rows("SELECT code FROM products",null)){ContentValues q=new ContentValues();q.put("rm_code",code);q.put("product_code",p.getInt("code"));q.put("qty",0);db.insert("recipes",q);}showRmMaster();}catch(Exception e){error(e);}});add(addrow);}try{for(JSONObject r:db.rows("SELECT * FROM rms ORDER BY CAST(code AS INTEGER)",null)){LinearLayout x=row();EditText code=edit("Code"),name=edit("Name"),uom=edit("UoM"),open=edit("Opening");code.setText(r.getString("code"));name.setText(r.getString("name"));uom.setText(r.getString("uom"));open.setText(fmt(r.getDouble("opening")));x.addView(code,new LinearLayout.LayoutParams(0,dp(52),1));x.addView(name,new LinearLayout.LayoutParams(0,dp(52),2));x.addView(uom,new LinearLayout.LayoutParams(0,dp(52),1));x.addView(open,new LinearLayout.LayoutParams(0,dp(52),1));Button save=btn("Save");x.addView(save);String old=r.getString("code");save.setOnClickListener(v->saveRm(old,code,name,uom,open));add(x);}}catch(Exception e){error(e);}}
 private void saveRm(String old,EditText c,EditText n,EditText u,EditText o){try{String nc=c.getText().toString().trim(),nn=n.getText().toString().trim(),nu=u.getText().toString().trim();if(nc.isEmpty()||nn.isEmpty())throw new Exception("Invalid RM");if(!nc.equals(old)&&db.one("SELECT code FROM rms WHERE code=?",new String[]{nc})!=null)throw new Exception("Duplicate RM Code");db.getWritableDatabase().beginTransaction();ContentValues v=new ContentValues();v.put("code",nc);v.put("name",nn);v.put("uom",nu.isEmpty()?"kg":nu);v.put("opening",Double.parseDouble(o.getText().toString()));db.update("rms",v,"code=?",new String[]{old});if(!nc.equals(old)){ContentValues q=new ContentValues();q.put("rm_code",nc);db.update("recipes",q,"rm_code=?",new String[]{old});ContentValues rr=new ContentValues();rr.put("rm_code",nc);db.update("receives",rr,"rm_code=?",new String[]{old});ContentValues rl=new ContentValues();rl.put("rm_code",nc);db.update("mixing2_batch_log",rl,"rm_code=?",new String[]{old});}db.getWritableDatabase().setTransactionSuccessful();db.getWritableDatabase().endTransaction();showRmMaster();}catch(Exception e){try{db.getWritableDatabase().endTransaction();}catch(Exception ignored){}error(e);}}
 private void showProductMaster(){clear("Product Master — Dynamic Add / Edit");if(admin()){LinearLayout x=row();EditText c=edit("New Product Code"),n=edit("New Product Name");x.addView(c,new LinearLayout.LayoutParams(0,dp(52),1));x.addView(n,new LinearLayout.LayoutParams(0,dp(52),2));Button a=btn("Add Product");x.addView(a);a.setOnClickListener(v->{try{int code=Integer.parseInt(c.getText().toString().trim());String name=n.getText().toString().trim();if(name.isEmpty())throw new Exception("Name required");if(db.one("SELECT code FROM products WHERE code=?",new String[]{String.valueOf(code)})!=null)throw new Exception("Duplicate Product Code");ContentValues p=new ContentValues();p.put("code",code);p.put("name",name);db.insert("products",p);for(JSONObject r:db.rows("SELECT code FROM rms",null)){ContentValues q=new ContentValues();q.put("rm_code",r.getString("code"));q.put("product_code",code);q.put("qty",0);db.insert("recipes",q);}showProductMaster();}catch(Exception e){error(e);}});add(x);}try{for(JSONObject p:db.rows("SELECT * FROM products ORDER BY code",null)){LinearLayout x=row();EditText c=edit("Code"),n=edit("Name");c.setText(p.getString("code"));n.setText(p.getString("name"));x.addView(c,new LinearLayout.LayoutParams(0,dp(52),1));x.addView(n,new LinearLayout.LayoutParams(0,dp(52),2));Button s=btn("Save");x.addView(s);int old=p.getInt("code");s.setOnClickListener(v->saveProduct(old,c,n));add(x);}}catch(Exception e){error(e);}}
 private void saveProduct(int old,EditText c,EditText n){try{int nc=Integer.parseInt(c.getText().toString().trim());String nn=n.getText().toString().trim();if(nn.isEmpty())throw new Exception("Name required");if(nc!=old&&db.one("SELECT code FROM products WHERE code=?",new String[]{String.valueOf(nc)})!=null)throw new Exception("Duplicate Product Code");db.getWritableDatabase().beginTransaction();ContentValues p=new ContentValues();p.put("code",nc);p.put("name",nn);db.update("products",p,"code=?",new String[]{String.valueOf(old)});if(nc!=old){ContentValues q=new ContentValues();q.put("product_code",nc);db.update("recipes",q,"product_code=?",new String[]{String.valueOf(old)});ContentValues b=new ContentValues();b.put("product_code",nc);db.update("batches",b,"product_code=?",new String[]{String.valueOf(old)});ContentValues bl=new ContentValues();bl.put("product_code",nc);db.update("mixing2_batch_log",bl,"product_code=?",new String[]{String.valueOf(old)});}db.getWritableDatabase().setTransactionSuccessful();db.getWritableDatabase().endTransaction();showProductMaster();}catch(Exception e){try{db.getWritableDatabase().endTransaction();}catch(Exception ignored){}error(e);}

for(int i=0;i<content.getChildCount();i++){
    View vv=content.getChildAt(i);
    if(vv instanceof Button){
        Button bb=(Button)vv;
        bb.setAllCaps(false);
        bb.setTextSize(14);
        bb.setPadding(dp(12),dp(10),dp(12),dp(10));
    }
}
}
 private void showRecipe(){clear("Mixing-2 Recipe — Dynamic RM × Product");if(!admin())return;try{List<JSONObject> ps=db.rows("SELECT * FROM products ORDER BY code",null);HorizontalScrollView hs=new HorizontalScrollView(this);TableLayout t=new TableLayout(this);TableRow h=new TableRow(this);h.addView(tv("RM",1));for(JSONObject p:ps)h.addView(tv(p.getString("name"),1));t.addView(h);List<JSONObject> rms=db.rows("SELECT * FROM rms ORDER BY CAST(code AS INTEGER)",null);for(JSONObject r:rms){TableRow tr=new TableRow(this);tr.addView(tv(r.getString("code")+" "+r.getString("name"),1));for(JSONObject p:ps){EditText e=edit("");JSONObject q=db.one("SELECT qty FROM recipes WHERE rm_code=? AND product_code=?",new String[]{r.getString("code"),p.getString("code")});e.setText(q==null?"0":fmt(q.getDouble("qty")));e.setTag(r.getString("code")+"|"+p.getString("code"));tr.addView(e,new TableRow.LayoutParams(dp(110),dp(52)));}t.addView(tr);}hs.addView(t);add(hs);Button save=btn("Save All Recipes");save.setOnClickListener(v->{for(int i=1;i<t.getChildCount();i++){TableRow tr=(TableRow)t.getChildAt(i);for(int j=1;j<tr.getChildCount();j++){EditText e=(EditText)tr.getChildAt(j);String[] k=e.getTag().toString().split("\\|");ContentValues z=new ContentValues();z.put("qty",num(e.getText().toString()));db.update("recipes",z,"rm_code=? AND product_code=?",new String[]{k[0],k[1]});}}toast("Recipe saved ✔");});add(save);

for(int i=0;i<content.getChildCount();i++){
    View vv=content.getChildAt(i);
    if(vv instanceof Button){
        Button bb=(Button)vv;
        bb.setAllCaps(false);
        bb.setTextSize(14);
        bb.setPadding(dp(12),dp(10),dp(12),dp(10));
    }else if(vv instanceof EditText){
        EditText ee=(EditText)vv;
        ee.setTextSize(15);
        ee.setPadding(dp(12),dp(12),dp(12),dp(12));
    }else if(vv instanceof Spinner){
        vv.setPadding(dp(8),dp(8),dp(8),dp(8));
    }
}}catch(Exception e){error(e);}}
 private void showDaily(){clear("RM Daily Entry — Add / Edit");try{
EditText d=edit("Date YYYY-MM-DD"),q=edit("Quantity"),v=edit("Voucher No"),note=edit("Note");d.setText(today());
Spinner rm=new Spinner(this);ArrayList<String>a=new ArrayList<>();for(JSONObject x:db.rows("SELECT code||' — '||name AS label FROM rms ORDER BY code",null))a.add(x.getString("label"));rm.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,a));
add(d);add(rm);add(v);add(q);add(note);
d.setTextSize(15);q.setTextSize(15);v.setTextSize(15);note.setTextSize(15);
d.setPadding(dp(12),dp(12),dp(12),dp(12));
q.setPadding(dp(12),dp(12),dp(12),dp(12));
v.setPadding(dp(12),dp(12),dp(12),dp(12));
note.setPadding(dp(12),dp(12),dp(12),dp(12));
rm.setPadding(dp(8),dp(8),dp(8),dp(8));
Button save=btn("Save Receive");
save.setTextSize(15);
save.setAllCaps(false);
save.setPadding(dp(12),dp(10),dp(12),dp(10));save.setOnClickListener(x->{try{
String label=String.valueOf(rm.getSelectedItem());if(label==null||label.equals("null"))throw new Exception("RM required");
String code=label.split(" — ",2)[0].trim();ContentValues z=new ContentValues();z.put("date",d.getText().toString().trim());z.put("rm_code",code);z.put("qty",num(q.getText().toString()));z.put("voucher_no",v.getText().toString().trim());z.put("note",note.getText().toString().trim());z.put("source","manual");db.insert("receives",z);toast("Receive saved ✔");showDaily();
}catch(Exception e){error(e);}});add(save);
add(tv("Recent Entries",1));
for(JSONObject r:db.rows("SELECT * FROM receives ORDER BY id DESC",null)){LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.VERTICAL);row.setPadding(dp(6),dp(8),dp(6),dp(8));
row.addView(tv("ID: "+r.optString("id")+"   "+r.optString("date")+"   RM: "+r.optString("rm_code")+"   Qty: "+fmt(r.optDouble("qty"))+"   Voucher: "+r.optString("voucher_no"),1));
row.addView(tv(r.optString("note"),1));
Button editB=btn("Edit");
editB.setTextSize(14);
editB.setAllCaps(false);editB.setOnClickListener(xx->{d.setText(r.optString("date"));q.setText(fmt(r.optDouble("qty")));v.setText(r.optString("voucher_no"));note.setText(r.optString("note"));String target=r.optString("rm_code");for(int i=0;i<a.size();i++)if(a.get(i).startsWith(target+" — ")){rm.setSelection(i);break;}save.setText("Update Receive #"+r.optString("id"));save.setOnClickListener(uu->{try{ContentValues z=new ContentValues();z.put("date",d.getText().toString().trim());z.put("rm_code",String.valueOf(rm.getSelectedItem()).split(" — ",2)[0].trim());z.put("qty",num(q.getText().toString()));z.put("voucher_no",v.getText().toString().trim());z.put("note",note.getText().toString().trim());int n=db.getWritableDatabase().update("receives",z,"id=?",new String[]{r.optString("id")});if(n!=1)throw new Exception("Update failed");toast("Receive updated ✔");showDaily();}catch(Exception e){error(e);}});});
row.setPadding(dp(12),dp(10),dp(12),dp(10));
row.setBackgroundColor(Color.WHITE);
row.addView(editB);
add(row);
Space rowSpace=new Space(this);
content.addView(rowSpace,new LinearLayout.LayoutParams(1,dp(6)));}
}catch(Exception e){error(e);}}
private void refreshDailyList(){showDaily();}
 private void editReceive(JSONObject r){try{LinearLayout b=new LinearLayout(this);b.setOrientation(LinearLayout.VERTICAL);EditText d=edit("Date"),q=edit("Quantity"),v=edit("Voucher No"),n=edit("Note");d.setText(r.optString("date"));q.setText(fmt(r.optDouble("qty")));v.setText(r.optString("voucher_no"));n.setText(r.optString("note"));Spinner rm=new Spinner(this);ArrayList<String>a=new ArrayList<>();int sel=0,i=0;for(JSONObject x:db.rows("SELECT code||' — '||name AS label FROM rms ORDER BY CAST(code AS INTEGER)",null)){a.add(x.getString("label"));if(x.getString("code").equals(r.optString("rm_code")))sel=i;i++;}rm.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,a));rm.setSelection(sel);b.addView(d);b.addView(rm);b.addView(q);b.addView(v);b.addView(n);new AlertDialog.Builder(this).setTitle("Edit Receive").setView(b).setNegativeButton("Cancel",null).setPositiveButton("Save",(x,w)->{try{double amount=num(q.getText().toString());if(amount<=0)throw new Exception("Quantity required");String code=String.valueOf(rm.getSelectedItem()).split(" — ")[0];ContentValues z=new ContentValues();z.put("date",d.getText().toString().trim());z.put("rm_code",code);z.put("qty",amount);z.put("voucher_no",v.getText().toString());z.put("note",n.getText().toString());db.update("receives",z,"id=?",new String[]{r.getString("id")});toast("Receive updated ✔");showDaily();}catch(Exception e){error(e);}}).show();}catch(Exception e){error(e);}}
 private void showBatch(){clear("Input Batch — Editable Batch Count");try{
  EditText d=edit("Production Date YYYY-MM-DD"),q=edit("Batch Count"),shift=edit("Shift 1/2/3");d.setText(today());
  Spinner p=new Spinner(this);ArrayList<String>a=new ArrayList<>();for(JSONObject x:db.rows("SELECT code||' — '||name AS label FROM products ORDER BY code",null))a.add(x.getString("label"));
  p.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,a));
add(d);add(p);add(shift);add(q);
d.setTextSize(15);shift.setTextSize(15);q.setTextSize(15);
d.setPadding(dp(12),dp(12),dp(12),dp(12));
shift.setPadding(dp(12),dp(12),dp(12),dp(12));
q.setPadding(dp(12),dp(12),dp(12),dp(12));
p.setPadding(dp(8),dp(8),dp(8),dp(8));
  Button save=btn("Save Batch Count");
save.setTextSize(15);
save.setAllCaps(false);
save.setPadding(dp(12),dp(10),dp(12),dp(10));save.setOnClickListener(v->{try{String label=String.valueOf(p.getSelectedItem());if(label==null||label.equals("null"))throw new Exception("Product required");String code=label.split(" — ")[0];int sh=Integer.parseInt(shift.getText().toString().trim());int bc=batchCount(q.getText().toString());if(sh<1||sh>3)throw new Exception("Shift must be 1, 2 or 3");if(bc<0)throw new Exception("Batch Count cannot be negative");
    ContentValues z=new ContentValues();z.put("date",d.getText().toString().trim());z.put("product_code",Integer.parseInt(code));z.put("shift",sh);z.put("qty",bc);z.put("saved_at",new Date().toString());
    JSONObject existing=db.one("SELECT id FROM batches WHERE date=? AND product_code=? AND shift=?",new String[]{d.getText().toString().trim(),code,String.valueOf(sh)});long batchId;if(existing==null){batchId=db.insert("batches",z);}else{batchId=existing.getLong("id");db.update("batches",z,"id=?",new String[]{existing.getString("id")});}syncBatchLog(batchId,d.getText().toString().trim(),Integer.parseInt(code),sh,bc,new Date().toString());toast("Batch Count saved ✔");showBatch();
  }catch(Exception e){error(e);}});add(save);
  add(title("Saved Batch Counts — Edit"));
  for(JSONObject x:db.rows("SELECT b.id,b.date,b.product_code,p.name,b.shift,b.qty FROM batches b LEFT JOIN products p ON p.code=b.product_code ORDER BY b.date DESC,b.shift ASC,b.id DESC LIMIT 100",null)){
    LinearLayout r=row();TextView t=new TextView(this);t.setText(x.optString("date")+" | "+x.optString("name")+" | Shift "+x.optString("shift")+" | Batch Count: "+batchCountText(x.optDouble("qty",0)));t.setLayoutParams(new LinearLayout.LayoutParams(0,-2,1));r.addView(t);
    Button e=btn("Edit");e.setOnClickListener(v->editBatchCount(x));r.addView(e,new LinearLayout.LayoutParams(dp(90),dp(52)));add(r);
  }
 }catch(Exception e){error(e);}}
 private String batchCountText(double n){return String.valueOf((int)Math.round(n));}
 private int batchCount(String s)throws Exception{String v=s.trim();if(v.isEmpty())throw new Exception("Batch Count required");double n=Double.parseDouble(v);if(n!=Math.rint(n))throw new Exception("Batch Count must be a whole number");if(n>2147483647)throw new Exception("Batch Count too large");return (int)n;}
 private void syncBatchLog(long batchId,String date,int productCode,int shift,int batchCount,String savedAt)throws Exception{db.delete("mixing2_batch_log","batch_id=?",new String[]{String.valueOf(batchId)});for(JSONObject rm:db.rows("SELECT rm_code,qty FROM recipes WHERE product_code=? AND qty<>0 ORDER BY rm_code",new String[]{String.valueOf(productCode)})){ContentValues l=new ContentValues();l.put("batch_id",batchId);l.put("date",date);l.put("product_code",productCode);l.put("shift",shift);l.put("rm_code",rm.getString("rm_code"));l.put("recipe_qty",rm.getDouble("qty"));l.put("batch_count",batchCount);l.put("consumption",batchCount*rm.getDouble("qty"));l.put("created_at",savedAt);db.insert("mixing2_batch_log",l);}}
 private void editBatchCount(JSONObject x){
  EditText bc=edit("Batch Count");bc.setText(batchCountText(x.optDouble("qty",0)));
  new AlertDialog.Builder(this).setTitle("Edit Shift Batch Count")
   .setMessage("এটি এই Shift-এ হওয়া মোট Batch-এর সংখ্যা। ৪ → ৫ করলে পরবর্তী একই calculation logic-এ ৫ ব্যবহার হবে।")
   .setView(bc).setNegativeButton("Cancel",null).setPositiveButton("Save Edit",(dialog,which)->{try{int n=batchCount(bc.getText().toString());ContentValues z=new ContentValues();z.put("qty",n);z.put("saved_at",new Date().toString());db.update("batches",z,"id=?",new String[]{x.getString("id")});syncBatchLog(x.getLong("id"),x.getString("date"),x.getInt("product_code"),x.getInt("shift"),n,new Date().toString());toast("Batch Count updated ✔");showBatch();}catch(Exception e){error(e);}}).show();
 }
 private int findSpinnerIndex(Spinner p,String code){for(int i=0;i<p.getCount();i++){String s=String.valueOf(p.getItemAtPosition(i));if(s.startsWith(code+" — "))return i;}return 0;}
 private void showCustom(){clear("Custom Sheets — Native Dynamic Designer");if(!admin())return;EditText name=edit("Sheet Name"),desc=edit("Description");add(name);add(desc);Button create=btn("Create Custom Sheet");create.setOnClickListener(v->{try{String id="S"+System.currentTimeMillis(),sn=name.getText().toString().trim();if(sn.isEmpty())throw new Exception("Sheet name required");if(db.one("SELECT id FROM custom_sheets WHERE lower(name)=lower(?)",new String[]{sn})!=null)throw new Exception("Duplicate Sheet Name");ContentValues x=new ContentValues();x.put("id",id);x.put("name",sn);x.put("description",desc.getText().toString().trim());x.put("access","owner");db.insert("custom_sheets",x);showCustomDefinition(id,sn);}catch(Exception e){error(e);}});add(create);try{for(JSONObject sh:db.rows("SELECT * FROM custom_sheets ORDER BY name",null)){String sid=sh.optString("id"),sname=sh.optString("name");LinearLayout sr=row();Button open=btn("Open: "+sname);open.setOnClickListener(v->openCustom(sid,sname));sr.addView(open,new LinearLayout.LayoutParams(0,dp(52),1));Button editSheet=btn("Edit");editSheet.setOnClickListener(v->showCustomDefinition(sid,sname));sr.addView(editSheet,new LinearLayout.LayoutParams(dp(90),dp(52)));add(sr);}}catch(Exception e){error(e);}}
 private void showCustomDefinition(String id,String currentName){clear("Sheet Definition — "+currentName);try{JSONObject sh=db.one("SELECT * FROM custom_sheets WHERE id=?",new String[]{id});if(sh==null)throw new Exception("Sheet not found");EditText nm=edit("Sheet Name");nm.setText(sh.optString("name"));EditText ds=edit("Description");ds.setText(sh.optString("description"));add(nm);add(ds);Button saveHead=btn("Save Sheet Name / Description");saveHead.setOnClickListener(v->{try{String nn=nm.getText().toString().trim();if(nn.isEmpty())throw new Exception("Sheet name required");JSONObject dup=db.one("SELECT id FROM custom_sheets WHERE lower(name)=lower(?) AND id<>?",new String[]{nn,id});if(dup!=null)throw new Exception("Duplicate Sheet Name");ContentValues x=new ContentValues();x.put("name",nn);x.put("description",ds.getText().toString().trim());db.update("custom_sheets",x,"id=?",new String[]{id});toast("Sheet definition saved ✔");showCustomDefinition(id,nn);}catch(Exception e){error(e);}});add(saveHead);Button addCol=btn("+ Add Column");addCol.setOnClickListener(v->columnDialog(id,-1));add(addCol);List<JSONObject> cs=db.rows("SELECT * FROM custom_cols WHERE sheet_id=? ORDER BY position",new String[]{id});for(JSONObject c:cs){long cid=c.getLong("id");LinearLayout r=row();TextView lab=new TextView(this);lab.setText(c.optString("position")+"  "+c.optString("name")+"  ["+c.optString("type")+"]"+(c.optString("formula").isEmpty()?"":"  "+c.optString("formula")));r.addView(lab,new LinearLayout.LayoutParams(0,dp(58),1));Button ed=btn("Edit");ed.setOnClickListener(v->columnDialog(id,cid));r.addView(ed,new LinearLayout.LayoutParams(dp(78),dp(52)));Button up=btn("↑");up.setOnClickListener(v->{moveColumn(cid,id,-1);});r.addView(up,new LinearLayout.LayoutParams(dp(45),dp(52)));Button dn=btn("↓");dn.setOnClickListener(v->{moveColumn(cid,id,1);});r.addView(dn,new LinearLayout.LayoutParams(dp(45),dp(52)));Button del=btn("Delete");del.setOnClickListener(v->{new AlertDialog.Builder(this).setTitle("Delete Column?").setMessage("Existing row values for this column will no longer be shown.").setNegativeButton("Cancel",null).setPositiveButton("Delete",(a,b)->{db.delete("custom_cols","id=?",new String[]{String.valueOf(cid)});repositionColumns(id);showCustomDefinition(id,nm.getText().toString());}).show();});r.addView(del,new LinearLayout.LayoutParams(dp(82),dp(52)));add(r);}Button open=btn("Open Sheet Rows");open.setOnClickListener(v->openCustom(id,nm.getText().toString()));add(open);Button delSheet=btn("Delete Sheet");delSheet.setOnClickListener(v->{new AlertDialog.Builder(this).setTitle("Delete Sheet?").setMessage("This removes the sheet definition and its rows permanently.").setNegativeButton("Cancel",null).setPositiveButton("Delete",(a,b)->{try{db.getWritableDatabase().beginTransaction();db.delete("custom_rows","sheet_id=?",new String[]{id});db.delete("custom_cols","sheet_id=?",new String[]{id});db.delete("custom_sheets","id=?",new String[]{id});db.getWritableDatabase().setTransactionSuccessful();db.getWritableDatabase().endTransaction();toast("Sheet deleted ✔");showCustom();}catch(Exception e){try{db.getWritableDatabase().endTransaction();}catch(Exception ignored){}error(e);}}).show();});add(delSheet);}catch(Exception e){error(e);}}
 private void columnDialog(String sheetId,long colId){LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(dp(12),0,dp(12),0);EditText name=edit("Column Name"),formula=edit("Formula e.g. =B2*C2 or =SUM(D2:F2) or =IF(E2<0,\"SHORTAGE\",\"OK\")");Spinner type=new Spinner(this);String[] types={"text","number","date","formula"};type.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,types));box.addView(name);box.addView(type);box.addView(formula);try{if(colId>0){JSONObject c=db.one("SELECT * FROM custom_cols WHERE id=?",new String[]{String.valueOf(colId)});if(c!=null){name.setText(c.optString("name"));formula.setText(c.optString("formula"));String ct=c.optString("type","text");for(int i=0;i<types.length;i++)if(types[i].equals(ct))type.setSelection(i);}}}catch(Exception e){error(e);return;}new AlertDialog.Builder(this).setTitle(colId>0?"Edit Column":"Add Column").setView(box).setNegativeButton("Cancel",null).setPositiveButton("Save",(d,w)->{try{String cn=name.getText().toString().trim();String ct=types[type.getSelectedItemPosition()];String f=formula.getText().toString().trim();if(cn.isEmpty())throw new Exception("Column name required");if(ct.equals("formula")&&f.isEmpty())throw new Exception("Formula required for formula column");JSONObject dup=db.one("SELECT id FROM custom_cols WHERE sheet_id=? AND lower(name)=lower(?) AND id<>?",new String[]{sheetId,cn,String.valueOf(colId)});if(dup!=null)throw new Exception("Duplicate Column Name");ContentValues x=new ContentValues();x.put("sheet_id",sheetId);x.put("name",cn);x.put("type",ct);x.put("formula",ct.equals("formula")?f:"");if(colId>0){JSONObject oldCol=db.one("SELECT name FROM custom_cols WHERE id=?",new String[]{String.valueOf(colId)});String oldName=oldCol==null?cn:oldCol.optString("name");db.update("custom_cols",x,"id=?",new String[]{String.valueOf(colId)});if(!oldName.equals(cn)){for(JSONObject rr:db.rows("SELECT id,row_json FROM custom_rows WHERE sheet_id=?",new String[]{sheetId})){JSONObject jo=new JSONObject(rr.optString("row_json","{}"));if(jo.has(oldName)){Object val=jo.remove(oldName);jo.put(cn,val);ContentValues rv=new ContentValues();rv.put("row_json",jo.toString());db.update("custom_rows",rv,"id=?",new String[]{rr.getString("id")});}}}}else{x.put("position",nextColumnPosition(sheetId));db.insert("custom_cols",x);}toast("Column saved ✔");showCustomDefinition(sheetId,db.one("SELECT name FROM custom_sheets WHERE id=?",new String[]{sheetId}).optString("name"));}catch(Exception e){error(e);}}).show();}
 private int nextColumnPosition(String id){try{JSONObject x=db.one("SELECT COALESCE(MAX(position),-1)+1 p FROM custom_cols WHERE sheet_id=?",new String[]{id});return x==null?0:x.getInt("p");}catch(Exception e){return 0;}}
 private void repositionColumns(String id){try{List<JSONObject> cs=db.rows("SELECT id FROM custom_cols WHERE sheet_id=? ORDER BY position,id",new String[]{id});for(int i=0;i<cs.size();i++){ContentValues x=new ContentValues();x.put("position",i);db.update("custom_cols",x,"id=?",new String[]{cs.get(i).getString("id")});}}catch(Exception ignored){}}
 private void openCustom(String id,String name){clear(name);try{List<JSONObject> cols=db.rows("SELECT * FROM custom_cols WHERE sheet_id=? ORDER BY position",new String[]{id});Button def=btn("Edit Sheet Name / Columns");def.setOnClickListener(v->showCustomDefinition(id,name));add(def);HorizontalScrollView hs=new HorizontalScrollView(this);TableLayout table=new TableLayout(this);TableRow h=new TableRow(this);for(JSONObject c:cols)h.addView(tv(c.getString("name"),1));h.addView(tv("Action",1));table.addView(h);for(JSONObject rr:db.rows("SELECT * FROM custom_rows WHERE sheet_id=? ORDER BY id",new String[]{id})){JSONObject data=new JSONObject(rr.getString("row_json"));TableRow tr=new TableRow(this);ArrayList<EditText> fields=new ArrayList<>();for(JSONObject c:cols){EditText e=edit("");String key=c.getString("name"),ct=c.optString("type","text");e.setText(data.optString(key,""));if(ct.equals("formula")){e.setEnabled(false);e.setText(calcFormula(c.optString("formula"),data,cols));}fields.add(e);tr.addView(e,new TableRow.LayoutParams(dp(150),dp(52)));}Button save=btn("Save");long rid=rr.getLong("id");save.setOnClickListener(v->{try{JSONObject out=new JSONObject();for(int i=0;i<cols.size();i++){JSONObject c=cols.get(i);if(!c.optString("type").equals("formula"))out.put(c.getString("name"),fields.get(i).getText().toString());}for(int pass=0;pass<cols.size()+1;pass++){for(JSONObject c:cols)if(c.optString("type").equals("formula"))out.put(c.getString("name"),calcFormula(c.optString("formula"),out,cols));}ContentValues x=new ContentValues();x.put("row_json",out.toString());db.update("custom_rows",x,"id=?",new String[]{String.valueOf(rid)});toast("Row saved ✔");openCustom(id,name);}catch(Exception e){error(e);}});tr.addView(save);Button delRow=btn("Delete");delRow.setOnClickListener(v->{new AlertDialog.Builder(this).setTitle("Delete Row?").setNegativeButton("Cancel",null).setPositiveButton("Delete",(a,b)->{db.delete("custom_rows","id=?",new String[]{String.valueOf(rid)});openCustom(id,name);}).show();});tr.addView(delRow);table.addView(tr);}hs.addView(table);add(hs);Button addrow=btn("+ Add Row");addrow.setOnClickListener(v->{try{ContentValues x=new ContentValues();x.put("sheet_id",id);x.put("row_json",new JSONObject().toString());db.insert("custom_rows",x);openCustom(id,name);}catch(Exception e){error(e);}});add(addrow);}catch(Exception e){error(e);}}
 private String calcFormula(String formula,JSONObject row,List<JSONObject> cols){try{String f=formula.trim();if(f.startsWith("="))f=f.substring(1).trim();java.util.regex.Matcher m=java.util.regex.Pattern.compile("(?i)^SUM\\(([^)]+)\\)$").matcher(f);if(m.find()){double sum=0;for(String ref:expandRange(m.group(1),cols))sum+=cellValue(ref,row,cols);return fmt(sum);}m=java.util.regex.Pattern.compile("(?i)^IF\\((.*?),(.*?),(.*?)\\)$").matcher(f);if(m.find()){String cond=m.group(1).trim(),a=stripQuote(m.group(2).trim()),b=stripQuote(m.group(3).trim());return evalCondition(cond,row,cols)?a:b;}String op=findOperator(f);if(op!=null){String[] z=f.split(java.util.regex.Pattern.quote(op),2);double a=cellValue(z[0].trim(),row,cols),b=cellValue(z[1].trim(),row,cols);if(op.equals("+"))return fmt(a+b);if(op.equals("-"))return fmt(a-b);if(op.equals("*"))return fmt(a*b);if(op.equals("/"))return b==0?"0":fmt(a/b);}return row.optString(f,f);}catch(Exception e){return "#ERR";}}
 private String findOperator(String s){for(String op:new String[]{"+","-","*","/"}){int p=s.indexOf(op,1);if(p>0)return op;}return null;}
 private boolean evalCondition(String c,JSONObject row,List<JSONObject> cols){for(String op:new String[]{">=","<=","!=","=","<",">"}){int p=c.indexOf(op);if(p>0){double a=cellValue(c.substring(0,p).trim(),row,cols),b=cellValue(c.substring(p+op.length()).trim(),row,cols);if(op.equals(">="))return a>=b;if(op.equals("<="))return a<=b;if(op.equals("!="))return a!=b;if(op.equals("="))return a==b;if(op.equals("<"))return a<b;return a>b;}}return false;}
 private String stripQuote(String s){return s.length()>=2&&s.startsWith("\"")&&s.endsWith("\"")?s.substring(1,s.length()-1):s;}
 private double cellValue(String ref,JSONObject row,List<JSONObject> cols){try{ref=ref.trim();if(ref.matches("[A-Za-z]+\\d+")){int ci=0;for(char ch:ref.toUpperCase().toCharArray()){if(Character.isLetter(ch))ci=ci*26+(ch-'A'+1);}ci--;if(ci>=0&&ci<cols.size())return num(row.optString(cols.get(ci).getString("name"),"0"));}return Double.parseDouble(ref);}catch(Exception e){return 0;}}
 private List<String> expandRange(String range,List<JSONObject> cols){List<String> out=new ArrayList<>();String[] z=range.trim().split(":");if(z.length!=2){out.add(range.trim());return out;}java.util.regex.Matcher a=java.util.regex.Pattern.compile("([A-Za-z]+)\\d+").matcher(z[0]);java.util.regex.Matcher b=java.util.regex.Pattern.compile("([A-Za-z]+)\\d+").matcher(z[1]);if(!a.find()||!b.find()){out.add(range.trim());return out;}int s=letters(a.group(1)),e=letters(b.group(1));for(int i=Math.min(s,e);i<=Math.max(s,e);i++)out.add(columnName(i)+"1");return out;} private String columnName(int n){StringBuilder x=new StringBuilder();n++;while(n>0){int r=(n-1)%26;x.insert(0,(char)('A'+r));n=(n-1)/26;}return x.toString();}
 private int letters(String s){int n=0;for(char c:s.toUpperCase().toCharArray())n=n*26+(c-'A'+1);return n-1;}
 private void showReports(){clear("Reports — Sheets");EditText month=edit("Month YYYY-MM");month.setText(today().substring(0,7));add(month);Button recv=btn("RM Receive Monthly — Day-wise");recv.setOnClickListener(v->showReceiveMonthly(month.getText().toString().trim()));add(recv);Button mixMonth=btn("RM Mixing-2 Monthly — Day-wise");mixMonth.setOnClickListener(v->showMixingMonthlySheet(month.getText().toString().trim()));add(mixMonth);Button mix=btn("Mixing-2 — Batch × Recipe Usage");mix.setOnClickListener(v->showMixing2(month.getText().toString().trim()));add(mix);Button batchLog=btn("RM Mixing-2 Batch Log");batchLog.setOnClickListener(v->showBatchLogSheet(month.getText().toString().trim()));add(batchLog);Button daily=btn("Daily Date Report");daily.setOnClickListener(v->showDailyDateSheet(month.getText().toString().trim()));add(daily);Button fin=btn("Final Monthly Usage");fin.setOnClickListener(v->showFinalMonthlySheet(month.getText().toString().trim()));add(fin);Button csv=btn("Export CSV");csv.setOnClickListener(v->exportCsv());add(csv);Button backup=btn("Backup JSON");backup.setOnClickListener(v->backupJson());add(backup);Button restore=btn("Restore JSON");restore.setOnClickListener(v->restoreJson());add(restore);Button company=btn("Company Name");company.setOnClickListener(v->editCompany());add(company);

for(int i=0;i<content.getChildCount();i++){
    View vv=content.getChildAt(i);
    if(vv instanceof Button){
        Button bb=(Button)vv;
        bb.setAllCaps(false);
        bb.setTextSize(14);
        bb.setPadding(dp(12),dp(10),dp(12),dp(10));
    }
} }

 private void showReceiveMonthly(String m){if(!validMonth(m)){error(new Exception("Month must be YYYY-MM"));return;}clear("RM Receive Monthly — Day-wise");try{int days=daysInMonth(m);HorizontalScrollView hs=new HorizontalScrollView(this);TableLayout t=new TableLayout(this);TableRow h=new TableRow(this);h.addView(tv("RM",1));for(int d=1;d<=days;d++)h.addView(tv(String.valueOf(d),1));h.addView(tv("Total",1));t.addView(h);for(JSONObject rm:db.rows("SELECT * FROM rms ORDER BY CAST(code AS INTEGER)",null)){TableRow tr=new TableRow(this);tr.addView(tv(rm.optString("code")+" "+rm.optString("name"),1));double total=0;for(int d=1;d<=days;d++){String date=m+"-"+String.format(Locale.US,"%02d",d);double q=receive(date,rm.getString("code"));total+=q;tr.addView(tv(fmt(q),1));}tr.addView(tv(fmt(total),1));t.addView(tr);}hs.addView(t);add(hs);Button pdf=btn("Print / PDF");pdf.setOnClickListener(v->reportReceive(m));add(pdf);}catch(Exception e){error(e);}}
 private void showMixingMonthlySheet(String m){if(!validMonth(m)){error(new Exception("Month must be YYYY-MM"));return;}clear("RM Mixing-2 Monthly — Day-wise");try{int days=daysInMonth(m);HorizontalScrollView hs=new HorizontalScrollView(this);TableLayout t=new TableLayout(this);TableRow h=new TableRow(this);h.addView(tv("RM",1));for(int d=1;d<=days;d++)h.addView(tv(String.valueOf(d),1));h.addView(tv("Total",1));t.addView(h);for(JSONObject rm:db.rows("SELECT * FROM rms ORDER BY CAST(code AS INTEGER)",null)){TableRow tr=new TableRow(this);tr.addView(tv(rm.optString("code")+" "+rm.optString("name"),1));double total=0;for(int d=1;d<=days;d++){String date=m+"-"+String.format(Locale.US,"%02d",d);double q=use(date,rm.getString("code"));total+=q;tr.addView(tv(fmt(q),1));}tr.addView(tv(fmt(total),1));t.addView(tr);}hs.addView(t);add(hs);Button pdf=btn("Print / PDF");pdf.setOnClickListener(v->reportMixingMonthly(m));add(pdf);}catch(Exception e){error(e);}}
 private void showBatchLogSheet(String m){if(!validMonth(m)){error(new Exception("Month must be YYYY-MM"));return;}clear("RM Mixing-2 Batch Log");try{HorizontalScrollView hs=new HorizontalScrollView(this);TableLayout t=new TableLayout(this);TableRow h=new TableRow(this);for(String x:new String[]{"Date","Product","Shift","RM","Recipe","Batches","Consumption"})h.addView(tv(x,1));t.addView(h);for(JSONObject x:db.rows("SELECT l.*,p.name product_name FROM mixing2_batch_log l LEFT JOIN products p ON p.code=l.product_code WHERE l.date LIKE ? ORDER BY l.date,l.product_code,l.shift,l.rm_code",new String[]{m+"-%"})){TableRow tr=new TableRow(this);for(String v:new String[]{x.optString("date"),x.optString("product_name",x.optString("product_code")),x.optString("shift"),x.optString("rm_code"),fmt(x.optDouble("recipe_qty")),fmt(x.optDouble("batch_count")),fmt(x.optDouble("consumption"))})tr.addView(tv(v,1));t.addView(tr);}hs.addView(t);add(hs);Button pdf=btn("Print / PDF");pdf.setOnClickListener(v->reportBatchLog(m));add(pdf);}catch(Exception e){error(e);}}
 private void showDailyDateSheet(String m){
  if(!validMonth(m)){error(new Exception("Month must be YYYY-MM"));return;}
  clear("Daily Date Report");
  try{
   EditText dateInput=edit("Date (YYYY-MM-DD)");dateInput.setText(today().startsWith(m)?today():m+"-01");add(dateInput);
   Button show=btn("Show Selected Date");add(show);
   Button pdf=btn("Save PDF / Share / Print Selected Date");add(pdf);
   Button monthPdf=btn("Save PDF / Print Full Month");add(monthPdf);
   LinearLayout tableHost=new LinearLayout(this);tableHost.setOrientation(LinearLayout.VERTICAL);add(tableHost);
   Runnable render=()->{try{
    String date=dateInput.getText().toString().trim();
    if(!date.matches("\\d{4}-\\d{2}-\\d{2}")||!date.startsWith(m+"-"))throw new Exception("Enter a valid date in selected month (YYYY-MM-DD)");
    tableHost.removeAllViews();
    HorizontalScrollView hs=new HorizontalScrollView(this);TableLayout t=new TableLayout(this);t.setStretchAllColumns(true);
    TableRow h=new TableRow(this);for(String col:new String[]{"Item Code","Item Name","UoM","Opening","Receive","Use","Closing","Status"})h.addView(tv(col,1));t.addView(h);
    for(JSONObject rm:db.rows("SELECT * FROM rms ORDER BY CAST(code AS INTEGER)",null)){
      String code=rm.getString("code");double o=opening(date,code),rec=receive(date,code),u=use(date,code),c=o+rec-u;
      TableRow tr=new TableRow(this);String status=c<0?"LOW/NEGATIVE":(c==0?"ZERO":"OK");
      for(String val:new String[]{code,rm.optString("name"),rm.optString("uom","KG"),fmt(o),fmt(rec),fmt(u),fmt(c),status})tr.addView(tv(val,1));t.addView(tr);
    }
    hs.addView(t);tableHost.addView(hs,new LinearLayout.LayoutParams(-1,-2));
   }catch(Exception e){error(e);}};
   show.setOnClickListener(v->render.run());pdf.setOnClickListener(v->{try{String date=dateInput.getText().toString().trim();if(!date.matches("\\d{4}-\\d{2}-\\d{2}")||!date.startsWith(m+"-"))throw new Exception("Enter a valid date in selected month (YYYY-MM-DD)");reportDaily(date);}catch(Exception e){error(e);}});
   monthPdf.setOnClickListener(v->reportDailyMonth(m));render.run();
  }catch(Exception e){error(e);}
 }
 private void showFinalMonthlySheet(String m){if(!validMonth(m)){error(new Exception("Month must be YYYY-MM"));return;}clear("Final Monthly Usage");try{TextView monthLabel=tv("Report month: "+m,1);monthLabel.setTextSize(16);monthLabel.setTypeface(null,1);monthLabel.setTextColor(Color.rgb(20,55,95));add(monthLabel);LinearLayout monthRow=row();EditText monthInput=edit("Select month (YYYY-MM)");monthInput.setInputType(android.text.InputType.TYPE_CLASS_DATETIME|android.text.InputType.TYPE_DATETIME_VARIATION_NORMAL);monthInput.setText(m);monthRow.addView(monthInput,new LinearLayout.LayoutParams(0,-2,1));Button loadMonth=btn("Load Month");monthRow.addView(loadMonth,new LinearLayout.LayoutParams(-2,-2));add(monthRow);loadMonth.setOnClickListener(v->{String chosen=monthInput.getText().toString().trim();if(!validMonth(chosen)){error(new Exception("Enter month as YYYY-MM, for example 2026-10"));return;}showFinalMonthlySheet(chosen);});HorizontalScrollView hs=new HorizontalScrollView(this);hs.setHorizontalScrollBarEnabled(true);hs.setFillViewport(false);TableLayout t=new TableLayout(this);t.setStretchAllColumns(false);TableRow h=new TableRow(this);for(String col:new String[]{"Item Code","Item Name","UoM","Opening Balance","Total Receive","Total Use","Closing Balance","Status"}){TextView cell=tv(col,1);cell.setMinWidth(dp(100));cell.setPadding(dp(8),dp(8),dp(8),dp(8));h.addView(cell);}t.addView(h);for(JSONObject rm:db.rows("SELECT * FROM rms ORDER BY CAST(code AS INTEGER)",null)){String code=rm.getString("code");double o=opening(m+"-01",code),rec=monthlyReceive(m,code),u=monthlyUse(m,code),cl=o+rec-u;String status=cl<0?"LOW/NEGATIVE":(cl==0?"ZERO":"OK");TableRow tr=new TableRow(this);for(String val:new String[]{code,rm.optString("name"),rm.optString("uom","KG"),fmt(o),fmt(rec),fmt(u),fmt(cl),status}){TextView cell=tv(val,1);cell.setMinWidth(dp(100));cell.setPadding(dp(8),dp(8),dp(8),dp(8));tr.addView(cell);}t.addView(tr);}hs.addView(t);add(hs);Button pdf=btn("Save PDF / Share / Print");pdf.setOnClickListener(v->reportMonthly(m));add(pdf);Button excel=btn("Export Excel-compatible CSV");excel.setOnClickListener(v->exportMonthlyCsv(m));add(excel);Button finalize=btn("Finalize Month (Admin)");finalize.setOnClickListener(v->finalizeMonth(m));add(finalize);Button snapshot=btn("View Saved Finalized Snapshot");snapshot.setOnClickListener(v->viewFinalizedSnapshot(m));add(snapshot);String saved=db.setting("finalized_month_"+m,"");TextView state=tv(saved.isEmpty()?"Finalized snapshot: Not saved":"Finalized snapshot: Saved (fixed historical snapshot)",1);state.setTextColor(saved.isEmpty()?Color.DKGRAY:Color.rgb(20,110,60));add(state);}catch(Exception e){error(e);}}
 private void viewFinalizedSnapshot(String month){try{String raw=db.setting("finalized_month_"+month,"");if(raw.isEmpty()){toast("No finalized snapshot saved for "+month);return;}JSONObject snapshot=new JSONObject(raw);StringBuilder out=new StringBuilder("Month: ").append(snapshot.optString("month",month)).append("\nFinalized at: ").append(snapshot.optString("finalized_at","Unknown")).append("\n\nCode | Item | UoM | Opening | Receive | Use | Closing | Status\n");JSONArray items=snapshot.optJSONArray("items");if(items!=null)for(int i=0;i<items.length();i++){JSONObject x=items.optJSONObject(i);if(x==null)continue;out.append(x.optString("code")).append(" | ").append(x.optString("name")).append(" | ").append(x.optString("uom")).append(" | ").append(fmt(x.optDouble("opening"))).append(" | ").append(fmt(x.optDouble("receive"))).append(" | ").append(fmt(x.optDouble("use"))).append(" | ").append(fmt(x.optDouble("closing"))).append(" | ").append(x.optString("status")).append("\n");}new AlertDialog.Builder(this).setTitle("Saved snapshot — "+month).setMessage(out.toString()).setPositiveButton("OK",null).show();}catch(Exception e){error(e);}}
 private void finalizeMonth(String month){new AlertDialog.Builder(this).setTitle("Finalize month "+month).setMessage("Save a fixed snapshot of this month’s opening, receive, use and closing balances? This records the current totals; later entries can still change live reports.").setNegativeButton("Cancel",null).setPositiveButton("Finalize",(d,w)->{try{JSONObject snapshot=new JSONObject();snapshot.put("month",month);snapshot.put("finalized_at",new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss",Locale.US).format(new java.util.Date()));JSONArray items=new JSONArray();for(JSONObject rm:db.rows("SELECT * FROM rms ORDER BY CAST(code AS INTEGER)",null)){String code=rm.getString("code");double o=opening(month+"-01",code),rec=monthlyReceive(month,code),u=monthlyUse(month,code),cl=o+rec-u;JSONObject item=new JSONObject();item.put("code",code);item.put("name",rm.optString("name"));item.put("uom",rm.optString("uom","KG"));item.put("opening",o);item.put("receive",rec);item.put("use",u);item.put("closing",cl);item.put("status",cl<0?"LOW/NEGATIVE":(cl==0?"ZERO":"OK"));items.put(item);}snapshot.put("items",items);db.setSetting("finalized_month_"+month,snapshot.toString());new AlertDialog.Builder(this).setTitle("Month finalized").setMessage("Saved snapshot for "+month+". The live reports remain available.").setPositiveButton("OK",null).show();}catch(Exception e){error(e);}}).show();}
 private boolean validMonth(String m){return m!=null&&m.matches("\\d{4}-\\d{2}")&&Integer.parseInt(m.substring(5,7))>=1&&Integer.parseInt(m.substring(5,7))<=12;} private int daysInMonth(String m){if(!validMonth(m))throw new IllegalArgumentException("Month must be YYYY-MM");Calendar c=Calendar.getInstance();c.set(Integer.parseInt(m.substring(0,4)),Integer.parseInt(m.substring(5,7))-1,1);return c.getActualMaximum(Calendar.DAY_OF_MONTH);}
 private String dailyStatus(double closing){return closing<0?"LOW/NEGATIVE":(closing==0?"ZERO":"OK");}
 private void reportDaily(String d){try{ArrayList<String[]> rows=new ArrayList<>();for(JSONObject r:db.rows("SELECT * FROM rms ORDER BY CAST(code AS INTEGER)",null)){String code=r.getString("code");double o=opening(d,code),rec=receive(d,code),u=use(d,code),c=o+rec-u;rows.add(new String[]{code,r.optString("name"),r.optString("uom","KG"),fmt(o),fmt(rec),fmt(u),fmt(c),dailyStatus(c)});}createLandscapeTablePdf("RM STOCK - DAILY DATE REPORT","Date: "+d,new String[]{"Item Code","Item Name","UoM","Opening","Receive","Use","Closing Balance","Status"},rows,"Daily-"+d);}catch(Exception e){error(e);}}
 private void reportDailyMonth(String m){try{StringBuilder s=new StringBuilder("RM STOCK - DAILY DATE REPORT\nMonth: ").append(m).append("\n\n");int days=daysInMonth(m);for(int d=1;d<=days;d++){String date=m+"-"+String.format(Locale.US,"%02d",d);s.append("Date: ").append(date).append("\nItem Code | Item Name | UoM | Opening | Receive | Use | Closing | Status\n");for(JSONObject r:db.rows("SELECT * FROM rms ORDER BY CAST(code AS INTEGER)",null)){String code=r.getString("code");double o=opening(date,code),rec=receive(date,code),u=use(date,code),c=o+rec-u;s.append(code).append(" | ").append(r.optString("name")).append(" | ").append(r.optString("uom","KG")).append(" | ").append(fmt(o)).append(" | ").append(fmt(rec)).append(" | ").append(fmt(u)).append(" | ").append(fmt(c)).append(" | ").append(dailyStatus(c)).append("\n");}s.append("\n");}sharePdf(s.toString(),"Daily-Report-"+m);}catch(Exception e){error(e);}}
 private void reportMonthly(String m){try{ArrayList<String[]> rows=new ArrayList<>();for(JSONObject r:db.rows("SELECT * FROM rms ORDER BY CAST(code AS INTEGER)",null)){String code=r.getString("code");double o=opening(m+"-01",code),rec=monthlyReceive(m,code),u=monthlyUse(m,code),cl=o+rec-u;rows.add(new String[]{code,r.optString("name"),r.optString("uom","KG"),fmt(o),fmt(rec),fmt(u),fmt(cl),dailyStatus(cl)});}createLandscapeTablePdf("RM STOCK - FINAL MONTHLY USAGE","Month: "+m,new String[]{"Item Code","Item Name","UoM","Opening Balance","Total Receive","Total Use","Closing Balance","Status"},rows,"Monthly-"+m);}catch(Exception e){error(e);}}
 private void createLandscapeTablePdf(String heading,String subheading,String[] headers,List<String[]> rows,String filename)throws Exception{PdfDocument doc=new PdfDocument();Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);paint.setColor(Color.BLACK);paint.setTypeface(Typeface.create("sans-serif",Typeface.NORMAL));final int pageW=842,pageH=595;final float left=20,right=20;float[] weights={1.0f,2.2f,.65f,1.0f,1.0f,.8f,1.15f,1.25f};float total=0;for(float w:weights)total+=w;float[] widths=new float[weights.length];for(int i=0;i<weights.length;i++)widths[i]=(pageW-left-right)*weights[i]/total;int pageNo=0;PdfDocument.Page page=null;Canvas canvas=null;float y=0;for(int index=-1;index<rows.size();index++){boolean headerRow=index==-1;if(page==null||y>pageH-45){if(page!=null){paint.setTextSize(8);canvas.drawText("Page "+pageNo,pageW-60,pageH-15,paint);doc.finishPage(page);}pageNo++;page=doc.startPage(new PdfDocument.PageInfo.Builder(pageW,pageH,pageNo).create());canvas=page.getCanvas();paint.setTextSize(13);paint.setTypeface(Typeface.DEFAULT_BOLD);canvas.drawText(db.setting("company","RM Stock"),left,20,paint);canvas.drawText(heading,left,38,paint);paint.setTextSize(10);paint.setTypeface(Typeface.DEFAULT);canvas.drawText(subheading,left,53,paint);y=72;paint.setTextSize(8);paint.setTypeface(Typeface.DEFAULT_BOLD);float x=left;for(int i=0;i<headers.length;i++){canvas.drawText(headers[i],x+2,y,paint);x+=widths[i];}y+=7;canvas.drawLine(left,y,pageW-right,y,paint);y+=15;}if(headerRow)continue;String[] cells=rows.get(index);paint.setTextSize(8);paint.setTypeface(Typeface.DEFAULT);float x=left;for(int i=0;i<cells.length;i++){String value=cells[i]==null?"":cells[i];float maxW=widths[i]-5;while(value.length()>1&&paint.measureText(value)>maxW)value=value.substring(0,value.length()-1);canvas.drawText(value,x+2,y,paint);x+=widths[i];}canvas.drawLine(left,y+4,pageW-right,y+4,paint);y+=17;}if(page!=null){paint.setTextSize(8);canvas.drawText("Page "+pageNo,pageW-60,pageH-15,paint);doc.finishPage(page);}File dir=new File(getFilesDir(),"reports");if(!dir.exists()&&!dir.mkdirs())throw new IOException("Cannot create report directory");File f=new File(dir,filename+".pdf");try(FileOutputStream out=new FileOutputStream(f)){doc.writeTo(out);}finally{doc.close();}shareExistingPdf(f);}
 private void reportReceive(String m){reportDaywiseLandscape(m,true);}
 private double receive(String d,String c)throws Exception{JSONObject x=db.one("SELECT COALESCE(SUM(qty),0) v FROM receives WHERE date=? AND rm_code=?",new String[]{d,c});return x==null?0:x.getDouble("v");}
 private double use(String d,String rm)throws Exception{JSONObject x=db.one("SELECT COALESCE(SUM(consumption),0) v FROM mixing2_batch_log WHERE date=? AND rm_code=?",new String[]{d,rm});return x==null?0:x.getDouble("v");}
 private double monthlyReceive(String m,String c)throws Exception{JSONObject x=db.one("SELECT COALESCE(SUM(qty),0) v FROM receives WHERE date LIKE ? AND rm_code=?",new String[]{m+"-%",c});return x==null?0:x.getDouble("v");}
 private double monthlyUse(String m,String c)throws Exception{Calendar cal=Calendar.getInstance();cal.set(Integer.parseInt(m.substring(0,4)),Integer.parseInt(m.substring(5,7))-1,1);int days=cal.getActualMaximum(Calendar.DAY_OF_MONTH);double s=0;for(int i=1;i<=days;i++)s+=use(m+"-"+String.format(Locale.US,"%02d",i),c);return s;}
 private double opening(String d,String c)throws Exception{
  // Opening is the base/master opening plus every dated movement strictly before this day.
  // This naturally carries closing stock across month/year boundaries instead of resetting on day 1.
  JSONObject base=db.one("SELECT opening FROM rms WHERE code=?",new String[]{c});
  double initial=base==null?0:base.optDouble("opening");
  JSONObject rec=db.one("SELECT COALESCE(SUM(qty),0) v FROM receives WHERE rm_code=? AND date<?",new String[]{c,d});
  JSONObject used=db.one("SELECT COALESCE(SUM(consumption),0) v FROM mixing2_batch_log WHERE rm_code=? AND date<?",new String[]{c,d});
  return initial+(rec==null?0:rec.optDouble("v"))-(used==null?0:used.optDouble("v"));
 }
 private void sharePdf(String text,String name)throws Exception{File f=createPdf(text,name);Uri u=FileProvider.getUriForFile(this,"com.rmstock.nativeapp.fileprovider",f);new AlertDialog.Builder(this).setTitle("Report ready").setItems(new String[]{"Save PDF","Share PDF","Print PDF"},(d,w)->{if(w==0){pendingPdf=f;Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.setType("application/pdf");i.putExtra(Intent.EXTRA_TITLE,f.getName());startActivityForResult(i,79);}else if(w==1){Intent i=new Intent(Intent.ACTION_SEND);i.setType("application/pdf");i.putExtra(Intent.EXTRA_STREAM,u);i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);startActivity(Intent.createChooser(i,"Share PDF"));}else{printPdf(f);}}).show();}
 private File createPdf(String text,String name)throws Exception{PdfDocument doc=new PdfDocument();Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);p.setTextSize(10*getResources().getDisplayMetrics().scaledDensity);p.setTypeface(Typeface.create("sans-serif",Typeface.NORMAL));ArrayList<String> lines=new ArrayList<>();for(String raw:text.split("\n")){if(raw.length()<=78)lines.add(raw);else{for(int i=0;i<raw.length();i+=78)lines.add(raw.substring(i,Math.min(raw.length(),i+78)));}}int page=1,y=42;PdfDocument.Page pg=null;Canvas c=null;for(String line:lines){if(pg==null||y>790){if(pg!=null){p.setTextSize(8*getResources().getDisplayMetrics().scaledDensity);c.drawText("Page "+(page-1),520,820,p);doc.finishPage(pg);}pg=doc.startPage(new PdfDocument.PageInfo.Builder(595,842,page++).create());c=pg.getCanvas();p.setTextSize(11*getResources().getDisplayMetrics().scaledDensity);c.drawText(db.setting("company","RM Stock"),24,24,p);p.setTextSize(10*getResources().getDisplayMetrics().scaledDensity);y=42;}c.drawText(line,24,y,p);y+=16;}if(pg!=null){p.setTextSize(8*getResources().getDisplayMetrics().scaledDensity);c.drawText("Page "+(page-1),520,820,p);doc.finishPage(pg);}File dir=new File(getFilesDir(),"reports");dir.mkdirs();File f=new File(dir,name+".pdf");FileOutputStream o=new FileOutputStream(f);doc.writeTo(o);o.close();doc.close();return f;}
 private void printPdf(File f){PrintManager pm=(PrintManager)getSystemService(PRINT_SERVICE);pm.print(f.getName(),new PrintAdapter(this,f),null);}
 private static class PrintAdapter extends PrintDocumentAdapter{Context c;File f;PrintAdapter(Context c,File f){this.c=c;this.f=f;}public void onLayout(PrintAttributes oldA,PrintAttributes newA,CancellationSignal s,LayoutResultCallback cb,Bundle m){if(s.isCanceled()){cb.onLayoutCancelled();return;}cb.onLayoutFinished(new PrintDocumentInfo.Builder(f.getName()).setContentType(PrintDocumentInfo.CONTENT_TYPE_DOCUMENT).setPageCount(PrintDocumentInfo.PAGE_COUNT_UNKNOWN).build(),true);}public void onWrite(PageRange[] pages,ParcelFileDescriptor dest,CancellationSignal s,WriteResultCallback cb){try{FileInputStream in=new FileInputStream(f);FileOutputStream out=new FileOutputStream(dest.getFileDescriptor());byte[] b=new byte[8192];int n;while((n=in.read(b))>0)out.write(b,0,n);in.close();cb.onWriteFinished(new PageRange[]{PageRange.ALL_PAGES});}catch(Exception e){cb.onWriteFailed(e.toString());}}}
 private void moveColumn(long cid,String sheet,int delta){try{List<JSONObject> cs=db.rows("SELECT id,position FROM custom_cols WHERE sheet_id=? ORDER BY position",new String[]{sheet});int idx=-1;for(int i=0;i<cs.size();i++)if(cs.get(i).getLong("id")==cid)idx=i;if(idx<0)return;int ni=idx+delta;if(ni<0||ni>=cs.size())return;long other=cs.get(ni).getLong("id");int p=cs.get(idx).getInt("position"),op=cs.get(ni).getInt("position");ContentValues a=new ContentValues();a.put("position",op);db.update("custom_cols",a,"id=?",new String[]{String.valueOf(cid)});ContentValues b=new ContentValues();b.put("position",p);db.update("custom_cols",b,"id=?",new String[]{String.valueOf(other)});showCustomDefinition(sheet,db.one("SELECT name FROM custom_sheets WHERE id=?",new String[]{sheet}).getString("name"));}catch(Exception e){error(e);}}
 private void showMixing2(String month){clear("Mixing-2 — Batch × Recipe Usage");try{for(JSONObject b:db.rows("SELECT date,product_code,shift,qty FROM batches WHERE date LIKE ? ORDER BY date,product_code,shift",new String[]{month+"-%"})){JSONObject p=db.one("SELECT name FROM products WHERE code=?",new String[]{b.optString("product_code")});LinearLayout r=row();TextView t=new TextView(this);t.setText(b.optString("date")+" | "+(p==null?b.optString("product_code"):p.getString("name"))+" | Shift "+b.optString("shift")+" | Batches "+batchCountText(b.getDouble("qty")));t.setLayoutParams(new LinearLayout.LayoutParams(0,-2,1));r.addView(t);Button e=btn("Edit Batch");e.setOnClickListener(v->editBatchCount(b));r.addView(e);Button er=btn("Edit RM Recipe");er.setOnClickListener(v->editMixingRecipe(b.optString("product_code"),month));r.addView(er);add(r);for(JSONObject rm:db.rows("SELECT rm_code,qty FROM recipes WHERE product_code=? AND qty<>0 ORDER BY rm_code",new String[]{b.optString("product_code")})){double use=b.getDouble("qty")*rm.getDouble("qty");TextView u=tv("   RM "+rm.getString("rm_code")+" = "+fmt(use),1);add(u);}}}catch(Exception e){error(e);}}
 private void editMixingRecipe(String productCode,String returnMonth){
  try{
   JSONObject p=db.one("SELECT name FROM products WHERE code=?",new String[]{productCode});
   clear("Mixing-2 RM Recipe — "+(p==null?productCode:p.getString("name")));
   for(JSONObject r:db.rows("SELECT code,name,uom FROM rms ORDER BY CAST(code AS INTEGER)",null)){
    JSONObject q=db.one("SELECT qty FROM recipes WHERE rm_code=? AND product_code=?",new String[]{r.getString("code"),productCode});
    LinearLayout line=row();
    TextView lab=tv(r.getString("code")+" — "+r.getString("name")+" ("+r.getString("uom")+")",1);
    line.addView(lab,new LinearLayout.LayoutParams(0,-2,1));
    EditText e=edit("Recipe Qty"); e.setText(q==null?"0":fmt(q.getDouble("qty"))); e.setTag(r.getString("code"));
    line.addView(e,new LinearLayout.LayoutParams(dp(110),dp(52))); content.addView(line);
   }
   Button save=btn("Save Mixing-2 RM Recipe");
   save.setOnClickListener(v->{
    try{
     for(int i=1;i<content.getChildCount()-1;i++){
      View vv=content.getChildAt(i);
      if(!(vv instanceof LinearLayout))continue;
      LinearLayout line=(LinearLayout)vv;
      for(int j=0;j<line.getChildCount();j++){
       View c=line.getChildAt(j);
       if(c instanceof EditText&&c.getTag()!=null){
        ContentValues z=new ContentValues(); z.put("qty",num(((EditText)c).getText().toString()));
        db.update("recipes",z,"rm_code=? AND product_code=?",new String[]{String.valueOf(c.getTag()),productCode});
       }
      }
     }
     toast("Mixing-2 RM recipe saved ✔"); showMixing2(returnMonth);
    }catch(Exception e){error(e);}
   });
   add(save);
  }catch(Exception e){error(e);}
 }
 private void exportMonthlyCsv(String month){try{StringBuilder s=new StringBuilder("Item Code,Item Name,UoM,Opening Balance,Total Receive,Total Use,Closing Balance,Status\r\n");for(JSONObject rm:db.rows("SELECT * FROM rms ORDER BY CAST(code AS INTEGER)",null)){String code=rm.getString("code");double o=opening(month+"-01",code),rec=monthlyReceive(month,code),u=monthlyUse(month,code),cl=o+rec-u;s.append(csvCell(code)).append(',').append(csvCell(rm.optString("name"))).append(',').append(csvCell(rm.optString("uom","KG"))).append(',').append(fmt(o)).append(',').append(fmt(rec)).append(',').append(fmt(u)).append(',').append(fmt(cl)).append(',').append(csvCell(cl<0?"LOW/NEGATIVE":cl==0?"ZERO":"OK")).append("\r\n");}shareCsv(s.toString(),"Final-Monthly-Usage-"+month+".csv");}catch(Exception e){error(e);}}
 private String csvCell(String v){return "\""+String.valueOf(v).replace("\"","\"\"")+"\"";}
 private void shareCsv(String data,String name){try{File f=new File(getCacheDir(),name);try(FileOutputStream out=new FileOutputStream(f)){out.write(("\uFEFF"+data).getBytes("UTF-8"));}pendingPdf=f;Uri u=FileProvider.getUriForFile(this,"com.rmstock.nativeapp.fileprovider",f);new AlertDialog.Builder(this).setTitle("Spreadsheet export ready").setItems(new String[]{"Save CSV (opens in Excel)","Share CSV"},(d,w)->{if(w==0){Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.setType("text/csv");i.putExtra(Intent.EXTRA_TITLE,name);startActivityForResult(i,82);}else{Intent i=new Intent(Intent.ACTION_SEND);i.setType("text/csv");i.putExtra(Intent.EXTRA_STREAM,u);i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);startActivity(Intent.createChooser(i,"Share spreadsheet"));}}).show();}catch(Exception e){error(e);}}
 private void reportDaywiseLandscape(String month,boolean receiveSheet){
  try{
   int days=daysInMonth(month);
   List<JSONObject> rms=db.rows("SELECT code,name FROM rms ORDER BY CAST(code AS INTEGER)",null);
   PdfDocument doc=new PdfDocument();
   Paint p=new Paint(Paint.ANTI_ALIAS_FLAG); p.setColor(Color.BLACK);
   final float left=18f, labelW=174f, totalW=42f, right=18f;
   final float dayW=(842f-left-labelW-totalW-right)/days;
   int page=1; PdfDocument.Page pg=null; Canvas c=null; float y=0;
   for(int ri=0;ri<rms.size();ri++){
    if(pg==null || y>555f){
     if(pg!=null){p.setTextSize(8f);c.drawText("Page "+(page-1),790,580,p);doc.finishPage(pg);}
     pg=doc.startPage(new PdfDocument.PageInfo.Builder(842,595,page++).create()); c=pg.getCanvas();
     p.setTextSize(12f); c.drawText(db.setting("company","RM Stock"),left,22,p);
     p.setTextSize(10f); c.drawText((receiveSheet?"RM Receive Monthly — Day-wise":"RM Mixing-2 Monthly — Day-wise")+" | "+month,left,40,p);
     p.setTextSize(7f); c.drawText("RM Code / Name",left,61,p);
     for(int d=1;d<=days;d++){
      String day=String.valueOf(d); float x=left+labelW+(d-1)*dayW;
      c.drawText(day,x+Math.max(0,(dayW-p.measureText(day))/2f),61,p);
     }
     c.drawText("Total",left+labelW+days*dayW+2,61,p);
     p.setStrokeWidth(.5f); c.drawLine(left,67,842-right,67,p);
     y=82;
    }
    JSONObject rm=rms.get(ri); String code=rm.optString("code");
    String label=code+" - "+rm.optString("name");
    p.setTextSize(7f);
    // Keep both item code and name visible; shrink text to fit the fixed label column.
    while(label.length()>1 && p.measureText(label)>labelW-5) { p.setTextSize(Math.max(5.5f,p.getTextSize()-.25f)); if(p.getTextSize()<=5.5f) break; }
    if(p.measureText(label)>labelW-5){while(label.length()>1&&p.measureText(label+"…")>labelW-5)label=label.substring(0,label.length()-1);label+="…";}
    c.drawText(label,left,y,p); p.setTextSize(5.5f); double total=0;
    for(int d=1;d<=days;d++){
     String date=month+"-"+String.format(Locale.US,"%02d",d);
     double q=receiveSheet?receive(date,code):use(date,code); total+=q;
     String value=fmt(q); float x=left+labelW+(d-1)*dayW;
     float tx=x+Math.max(0,(dayW-p.measureText(value))/2f);
     c.drawText(value,tx,y,p);
    }
    String totalText=fmt(total); c.drawText(totalText,left+labelW+days*dayW+2,y,p);
    y+=14f;
   }
   if(pg!=null){p.setTextSize(8f);c.drawText("Page "+(page-1),790,580,p);doc.finishPage(pg);}
   File dir=new File(getFilesDir(),"reports");dir.mkdirs();
   File f=new File(dir,(receiveSheet?"Receive-Daywise-":"Mixing2-Daywise-")+month+".pdf");
   try(FileOutputStream out=new FileOutputStream(f)){doc.writeTo(out);} doc.close(); shareExistingPdf(f);
  }catch(Exception e){error(e);}
 }
 private void shareExistingPdf(File f)throws Exception{Uri u=FileProvider.getUriForFile(this,"com.rmstock.nativeapp.fileprovider",f);new AlertDialog.Builder(this).setTitle("Report ready").setItems(new String[]{"Save PDF","Share PDF","Print PDF"},(d,w)->{if(w==0){pendingPdf=f;Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.setType("application/pdf");i.putExtra(Intent.EXTRA_TITLE,f.getName());startActivityForResult(i,79);}else if(w==1){Intent i=new Intent(Intent.ACTION_SEND);i.setType("application/pdf");i.putExtra(Intent.EXTRA_STREAM,u);i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);startActivity(Intent.createChooser(i,"Share PDF"));}else printPdf(f);}).show();}
 private void reportBatchLog(String month){try{StringBuilder s=new StringBuilder("RM MIXING-2 BATCH LOG\nMonth: ").append(month).append("\n\nDate | Product | Shift | Batches | RM Code | Recipe Qty | Consumption\n");for(JSONObject x:db.rows("SELECT l.date,l.product_code,l.shift,l.batch_count,l.rm_code,l.recipe_qty,l.consumption,p.name FROM mixing2_batch_log l LEFT JOIN products p ON p.code=l.product_code WHERE l.date LIKE ? ORDER BY l.date,l.product_code,l.shift,l.rm_code",new String[]{month+"-%"})){s.append(x.getString("date")).append(" | ").append(x.optString("name",x.getString("product_code"))).append(" | Shift ").append(x.getString("shift")).append(" | ").append(batchCountText(x.getDouble("batch_count"))).append(" | ").append(x.getString("rm_code")).append(" | ").append(fmt(x.getDouble("recipe_qty"))).append(" | ").append(fmt(x.getDouble("consumption"))).append("\n");}sharePdf(s.toString(),"Mixing2-Batch-Log-"+month);}catch(Exception e){error(e);}}
 private void reportMixingMonthly(String month){reportDaywiseLandscape(month,false);}
 private void editCompany(){EditText e=edit("Company Name");e.setText(db.setting("company","RM Stock"));new AlertDialog.Builder(this).setTitle("Company Name").setView(e).setNegativeButton("Cancel",null).setPositiveButton("Save",(d,w)->{String x=e.getText().toString().trim();if(!x.isEmpty()){db.setSetting("company",x);toast("Company name saved ✔");}}).show();}
 private void backupJson(){try{JSONObject all=new JSONObject();all.put("version",4);all.put("company",db.setting("company","RM Stock"));JSONArray tables=new JSONArray();String[] ts={"rms","products","recipes","batches","receives","approvals","custom_sheets","custom_cols","custom_rows","mixing2_batch_log","settings"};for(String t:ts){JSONObject z=new JSONObject();z.put("table",t);z.put("rows",new JSONArray());for(JSONObject r:db.rows("SELECT * FROM "+t,null))z.getJSONArray("rows").put(r);tables.put(z);}all.put("tables",tables);File f=new File(getCacheDir(),"rmstock-backup.json");try(FileOutputStream o=new FileOutputStream(f)){o.write(all.toString(2).getBytes("UTF-8"));}pendingPdf=f;Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.setType("application/json");i.putExtra(Intent.EXTRA_TITLE,"rmstock-backup.json");startActivityForResult(i,80);}catch(Exception e){error(e);}}
 private void restoreJson(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("application/json");i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,81);}
 private void importBackup(Uri u){try{InputStream in=getContentResolver().openInputStream(u);ByteArrayOutputStream b=new ByteArrayOutputStream();byte[] z=new byte[8192];int n;while((n=in.read(z))>0)b.write(z,0,n);in.close();JSONObject all=new JSONObject(b.toString("UTF-8"));if(!all.has("tables"))throw new Exception("Invalid backup");new AlertDialog.Builder(this).setTitle("Restore Backup?").setMessage("Current data will be replaced. Continue?").setNegativeButton("Cancel",null).setPositiveButton("Restore",(d,w)->{try{restoreTables(all.getJSONArray("tables"));toast("Backup restored ✔");build();showDashboard();}catch(Exception e){error(e);}}).show();}catch(Exception e){error(e);}}
 private void restoreTables(JSONArray tables)throws Exception{SQLiteDatabase x=db.getWritableDatabase();x.beginTransaction();try{String[] ts={"receives","mixing2_batch_log","batches","custom_rows","custom_cols","custom_sheets","approvals","recipes","products","rms","settings"};for(String t:ts)x.delete(t,null,null);for(int i=0;i<tables.length();i++){JSONObject t=tables.getJSONObject(i);String tn=t.getString("table");JSONArray rs=t.getJSONArray("rows");for(int j=0;j<rs.length();j++){JSONObject r=rs.getJSONObject(j);ContentValues v=new ContentValues();Iterator<String> it=r.keys();while(it.hasNext()){String k=it.next();Object val=r.get(k);if(val==JSONObject.NULL)continue;v.put(k,String.valueOf(val));}x.insertWithOnConflict(tn,null,v,SQLiteDatabase.CONFLICT_REPLACE);}}x.setTransactionSuccessful();}finally{x.endTransaction();}}
 private void exportCsv(){try{File f=new File(getCacheDir(),"rmstock-export.csv");FileOutputStream o=new FileOutputStream(f);String[] ts={"rms","products","recipes","batches","receives","custom_sheets","custom_cols","custom_rows","mixing2_batch_log"};for(String t:ts){o.write(("\n["+t+"]\n").getBytes("UTF-8"));List<JSONObject> rs=db.rows("SELECT * FROM "+t,null);if(!rs.isEmpty()){JSONArray a=rs.get(0).names();for(int j=0;j<a.length();j++){if(j>0)o.write(',');o.write(csv(a.optString(j)).getBytes("UTF-8"));}o.write('\n');for(JSONObject r:rs){for(int j=0;j<a.length();j++){if(j>0)o.write(',');o.write(csv(r.optString(a.optString(j))).getBytes("UTF-8"));}o.write('\n');}}}o.close();Intent i=new Intent(Intent.ACTION_SEND);i.setType("text/csv");i.putExtra(Intent.EXTRA_STREAM,FileProvider.getUriForFile(this,"com.rmstock.nativeapp.fileprovider",f));i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);startActivity(Intent.createChooser(i,"Export CSV"));}catch(Exception e){error(e);}}
 private String csv(String s){return "\""+s.replace("\"","\"\"")+"\"";}
 private void showAI(){clear("Offline AI Agent — Voucher Draft");TextView t=new TextView(this);t.setText("Scan voucher → offline OCR → Draft → Admin review/approval → Daily Entry. AI never writes directly before approval.");add(t);Button b=btn("📷 Scan Voucher");b.setOnClickListener(v->startCamera());add(b);}
 private void startCamera(){if(ContextCompat.checkSelfPermission(this,Manifest.permission.CAMERA)!=PackageManager.PERMISSION_GRANTED){ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.CAMERA},CAM);return;}try{File dir=new File(getCacheDir(),"images");dir.mkdirs();File f=File.createTempFile("voucher_",".jpg",dir);photoUri=FileProvider.getUriForFile(this,"com.rmstock.nativeapp.fileprovider",f);Intent i=new Intent(MediaStore.ACTION_IMAGE_CAPTURE);i.putExtra(MediaStore.EXTRA_OUTPUT,photoUri);i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_WRITE_URI_PERMISSION);startActivityForResult(i,PHOTO);}catch(Exception e){error(e);}}
 @Override public void onRequestPermissionsResult(int r,String[] p,int[] g){super.onRequestPermissionsResult(r,p,g);if(r==CAM&&g.length>0&&g[0]==PackageManager.PERMISSION_GRANTED)startCamera();}
 @Override protected void onActivityResult(int r,int c,@Nullable Intent d){super.onActivityResult(r,c,d);if(r==PHOTO&&c==RESULT_OK&&photoUri!=null)ocr(photoUri); if(r==79&&c==RESULT_OK&&d!=null&&pendingPdf!=null){try{OutputStream out=getContentResolver().openOutputStream(d.getData());FileInputStream in=new FileInputStream(pendingPdf);byte[] b=new byte[8192];int n;while((n=in.read(b))>0)out.write(b,0,n);in.close();out.close();toast("PDF saved ✔");}catch(Exception e){error(e);}} if(r==82&&c==RESULT_OK&&d!=null&&pendingPdf!=null){try{OutputStream out=getContentResolver().openOutputStream(d.getData());FileInputStream in=new FileInputStream(pendingPdf);byte[] z=new byte[8192];int n;while((n=in.read(z))>0)out.write(z,0,n);in.close();out.close();toast("CSV saved — open with Excel ✔");}catch(Exception e){error(e);}} if(r==80&&c==RESULT_OK&&d!=null&&pendingPdf!=null){try{OutputStream out=getContentResolver().openOutputStream(d.getData());FileInputStream in=new FileInputStream(pendingPdf);byte[] b=new byte[8192];int n;while((n=in.read(b))>0)out.write(b,0,n);in.close();out.close();toast("Backup saved ✔");}catch(Exception e){error(e);}} if(r==81&&c==RESULT_OK&&d!=null)importBackup(d.getData());}
 private void ocr(Uri u){new Thread(()->{String txt="";try{Bitmap bm=BitmapFactory.decodeStream(getContentResolver().openInputStream(u));File base=new File(getFilesDir(),"tess"),td=new File(base,"tessdata");td.mkdirs();copy("tessdata/eng.traineddata",new File(td,"eng.traineddata"));copy("tessdata/ben.traineddata",new File(td,"ben.traineddata"));TessBaseAPI api=new TessBaseAPI();if(!api.init(base.getAbsolutePath(),"eng+ben"))throw new Exception("OCR init failed");api.setImage(bm);txt=api.getUTF8Text();api.recycle();bm.recycle();}catch(Exception e){txt="OCR_ERROR: "+e.getMessage();}final String z=txt;main.post(()->showAIDraft(z));}).start();}
 private void showAIDraft(String raw){clear("AI Draft — Admin Approval");EditText date=edit("Date"),voucher=edit("Voucher No"),rm=edit("RM Code"),qty=edit("Quantity");date.setText(findDate(raw));voucher.setText(findVoucher(raw));rm.setText(findRm(raw));qty.setText(findQty(raw));add(date);add(voucher);add(rm);add(qty);TextView o=new TextView(this);o.setText("OCR text:\n"+raw);o.setPadding(0,dp(12),0,dp(12));add(o);Button approve=btn("Approve & Save to Daily Entry");approve.setOnClickListener(v->{if(!admin())return;try{String code=rm.getText().toString().trim();if(db.one("SELECT code FROM rms WHERE code=?",new String[]{code})==null)throw new Exception("RM Code not found");ContentValues x=new ContentValues();x.put("date",date.getText().toString().trim());x.put("rm_code",code);x.put("qty",num(qty.getText().toString()));x.put("note","Offline AI approved");x.put("voucher_no",voucher.getText().toString().trim());x.put("source","offline-ai");db.insert("receives",x);toast("AI Draft approved ✔");showDaily();}catch(Exception e){error(e);}});add(approve);}
 private String findDate(String s){java.util.regex.Matcher m=java.util.regex.Pattern.compile("(20\\d{2}[-/]\\d{1,2}[-/]\\d{1,2}|\\d{1,2}[-/]\\d{1,2}[-/]20\\d{2})").matcher(s);if(m.find()){String x=m.group(1).replace('/','-');String[] z=x.split("-");if(z[0].length()==4)return String.format(Locale.US,"%04d-%02d-%02d",Integer.parseInt(z[0]),Integer.parseInt(z[1]),Integer.parseInt(z[2]));return String.format(Locale.US,"%04d-%02d-%02d",Integer.parseInt(z[2]),Integer.parseInt(z[1]),Integer.parseInt(z[0]));}return today();}
 private String findVoucher(String s){java.util.regex.Matcher m=java.util.regex.Pattern.compile("(?i)(voucher|vch|challan)[^A-Za-z0-9]{0,8}([A-Z0-9\\-/]+)").matcher(s);return m.find()?m.group(2):"";} private String findQty(String s){java.util.regex.Matcher m=java.util.regex.Pattern.compile("(?i)(qty|quantity)[^0-9]{0,8}([0-9]+(?:\\.[0-9]+)?)").matcher(s);return m.find()?m.group(2):"0";} private String findRm(String s){try{for(JSONObject r:db.rows("SELECT * FROM rms",null)){String n=r.getString("name").toLowerCase();if(s.toLowerCase().contains(n))return r.getString("code");if(s.contains(r.getString("code")))return r.getString("code");}}catch(Exception ignored){}return "";}
 private TextView tv(String s,int dummy){TextView t=new TextView(this);t.setText(s);t.setPadding(dp(6),dp(8),dp(6),dp(8));return t;}
 private String today(){return new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(new Date());} private String fmt(double x){return String.format(Locale.US,"%.3f",x).replaceAll("0+$","").replaceAll("\\.$","");} private double num(String s){try{return Double.parseDouble(s.trim());}catch(Exception e){return 0;}} private void copy(String a,File o)throws Exception{if(o.exists()&&o.length()>0)return;InputStream in=getAssets().open(a);FileOutputStream f=new FileOutputStream(o);byte[] b=new byte[8192];int n;while((n=in.read(b))>0)f.write(b,0,n);in.close();f.close();} private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();} private void error(Exception e){toast(e.getMessage()==null?"Error":e.getMessage());}
}
