# RM-Stock source update notes

This package includes source-level updates to the existing native Android project.

- Daily Date Report includes selected-date PDF save/share/print and full-month PDF output.
- Final Monthly Usage includes a spreadsheet-style table, PDF save/share/print, and Excel-compatible CSV export.
- The two Day-wise reports use landscape A4 PDF with repeated title/header on each page and dynamically sized date columns for the selected month.
- Daily opening is the master opening plus all earlier receive movements minus all earlier Mixing-2 usage, so month/year changes carry the balance forward.
- Dashboard ticker and compact horizontally scrollable bottom navigation are present in the source.

## Verification limitations

The Gradle wrapper could not download Gradle 8.2 in this environment because DNS/network access to services.gradle.org failed. Therefore this source has not been confirmed by a successful Android build or on-device test. The currently inspected source does not contain an implementation named “Finalize Month”; do not assume that behavior is available or preserved until the original repository version is compared and the feature is verified. Make a backup of existing app data before installing any build.

## অতিরিক্ত সংশোধন
- Final Monthly Usage-এ `Finalize Month (Admin)` যোগ করা হয়েছে। এটি ওই মাসের Opening/Receive/Use/Closing/Status-এর একটি timestamp-সহ snapshot `settings`-এ সংরক্ষণ করে। এটি live report-কে lock করে না।
- Build যাচাই: এই পরিবেশে Gradle distribution ডাউনলোড করার নেটওয়ার্ক নেই এবং system Gradle-ও ইনস্টল নেই; তাই APK build সফল হয়েছে বলে দাবি করা যাচ্ছে না।
